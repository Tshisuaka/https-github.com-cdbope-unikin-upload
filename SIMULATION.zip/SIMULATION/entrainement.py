from __future__ import absolute_import
from __future__ import print_function
from importlib.resources import path
import os
import matplotlib.pyplot as plt
import datetime
import random
import traci
import numpy as np
import timeit
import math
from base64 import decode
os.environ['TF_CPP_MIN_LOG_LEVEL']='2'
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras import losses
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.utils import plot_model
from tensorflow.keras.models import load_model
import sys
from tqdm import tqdm
from shutil import copyfile
from scipy.stats import invweibull 
from parametres.utilitaires import importerConfigurationEntrainement, cheminEntrainementDef, sumoDef


class GenerateurTrafic:
    def __init__(self, maxEtapes, nbreVehiculeGenerer):
        self._n_cars_generated = nbreVehiculeGenerer 
        self._max_steps = maxEtapes

    def generate_routefile(self, seed):
        np.random.seed(seed) 
        timings = np.random.weibull(2, self._n_cars_generated)
        #timings = np.random.poisson(2, self._n_cars_generated)
        #timings = np.random.normal(2, 0.1, self._n_cars_generated)
        #timings = np.random.poisson(5, self._n_cars_generated)
        timings = np.sort(timings)

        car_gen_steps = []
        min_old = math.floor(timings[1])
        max_old = math.ceil(timings[-1])
        min_new = 0
        max_new = self._max_steps
        for value in timings:
            car_gen_steps = np.append(car_gen_steps, ((max_new - min_new) / (max_old - min_old)) * (value - max_old) + max_new)

        car_gen_steps = np.rint(car_gen_steps)

        with open("parametres/carrefour/episode.rou.xml", "w") as routes:
            print("""<routes>
            
            <vType id="emergency_auto" Vclass="emergency" accel="2.6" decel="4.5"  length="6.0" minGap="2.5" maxSpeed="30" sigma="0.5" speedDev="0" color="red" />
			<vType id="standard_car" Vclass="passenger" accel="1.5" decel="4.5" length="5.0" minGap="2.5" maxSpeed="20" sigma="0.5" speedDev="0.1" />
			<vType id="bus_auto" Vclass="bus" accel="1.5" decel="4.5"  length="10" minGap="2.5" maxSpeed="20" sigma="0.5" speedDev="0.1" />
			<vType id="authority_auto" Vclass="authority" accel="2.6" decel="4.5"  length="6.0" minGap="2.5" maxSpeed="35" sigma="0.5" speedDev="0" color="blue" />

            <route id="W_N" edges="W2TL TL2N"/>
            <route id="W_E" edges="W2TL TL2E"/>
            <route id="W_S" edges="W2TL TL2S"/>
            <route id="N_W" edges="N2TL TL2W"/>
            <route id="N_E" edges="N2TL TL2E"/>
            <route id="N_S" edges="N2TL TL2S"/>
            <route id="E_W" edges="E2TL TL2W"/>
            <route id="E_N" edges="E2TL TL2N"/>
            <route id="E_S" edges="E2TL TL2S"/>
            <route id="S_W" edges="S2TL TL2W"/>
            <route id="S_N" edges="S2TL TL2N"/>
            <route id="S_E" edges="S2TL TL2E"/>""", file=routes)

            for car_counter, step in enumerate(car_gen_steps):
                straight_or_turn = np.random.uniform()
                if straight_or_turn < 0.80: 
                    route_straight = np.random.randint(1, 5)  
                    if route_straight == 1:
                        print('    <vehicle id="W_E_%i" type="standard_car" route="W_E" depart="%s" departLane="random" departSpeed="10" />' % (car_counter, step), file=routes)
                    elif route_straight == 2:
                        print('    <vehicle id="E_W_%i" type="emergency_auto" route="E_W" depart="%s" departLane="random" departSpeed="10" />' % (car_counter, step), file=routes)
                    elif route_straight == 3:
                        print('    <vehicle id="N_S_%i" type="authority_auto" route="N_S" depart="%s" departLane="random" departSpeed="10" />' % (car_counter, step), file=routes)
                    else:
                        print('    <vehicle id="S_N_%i" type="bus_auto" route="S_N" depart="%s" departLane="random" departSpeed="10" />' % (car_counter, step), file=routes)
                else:  
                    route_turn = np.random.randint(1, 9)  
                    if route_turn == 1:
                        print('    <vehicle id="W_N_%i" type="standard_car" route="W_N" depart="%s" departLane="random" departSpeed="10" />' % (car_counter, step), file=routes)
                    elif route_turn == 2:
                        print('    <vehicle id="W_S_%i" type="authority_auto" route="W_S" depart="%s" departLane="random" departSpeed="10" />' % (car_counter, step), file=routes)
                    elif route_turn == 3:
                        print('    <vehicle id="N_W_%i" type="standard_car" route="N_W" depart="%s" departLane="random" departSpeed="10" />' % (car_counter, step), file=routes)
                    elif route_turn == 4:
                        print('    <vehicle id="N_E_%i" type="standard_car" route="N_E" depart="%s" departLane="random" departSpeed="10" />' % (car_counter, step), file=routes)
                    elif route_turn == 5:
                        print('    <vehicle id="E_N_%i" type="bus_auto" route="E_N" depart="%s" departLane="random" departSpeed="10" />' % (car_counter, step), file=routes)
                    elif route_turn == 6:
                        print('    <vehicle id="E_S_%i" type="authority_auto" route="E_S" depart="%s" departLane="random" departSpeed="10" />' % (car_counter, step), file=routes)
                    elif route_turn == 7:
                        print('    <vehicle id="S_W_%i" type="standard_car" route="S_W" depart="%s" departLane="random" departSpeed="10" />' % (car_counter, step), file=routes)
                    elif route_turn == 8:
                        print('    <vehicle id="S_E_%i" type="bus_auto" route="S_E" depart="%s" departLane="random" departSpeed="10" />' % (car_counter, step), file=routes)

            print("</routes>", file=routes)

PHASE_NS_GREEN = 0  
PHASE_NS_YELLOW = 1
PHASE_NSL_GREEN = 2  
PHASE_NSL_YELLOW = 3
PHASE_EW_GREEN = 4  
PHASE_EW_YELLOW = 5
PHASE_EWL_GREEN = 6  
PHASE_EWL_YELLOW = 7

class Simulation:
    def __init__(self, modele, memoire, TrafficGen, sumo_cmd, gamma, maxEtapes, dureeVert, dureeJaune, nbreEtats, nbreActions, epoqueFormation):
        self._Model = modele
        self._Memory = memoire
        self._TrafficGen = TrafficGen
        self._gamma = gamma
        self._step = 0
        self._sumo_cmd = sumo_cmd
        self._max_steps = maxEtapes
        self._green_duration = dureeVert
        self._yellow_duration = dureeJaune
        self._num_states = nbreEtats
        self._num_actions = nbreActions
        self._reward_store = []
        self._cumulative_wait_store = []
        self._avg_queue_length_store = []
        self._training_epochs = epoqueFormation


    def run(self, episode, epsilon):
        start_time = timeit.default_timer()

        self._TrafficGen.generate_routefile(seed=episode)
        traci.start(self._sumo_cmd)
        print("Simulation en cours ...")

        self._step = 0
        self._waiting_times = {}
        self._sum_neg_reward = 0
        self._sum_queue_length = 0
        self._sum_waiting_time = 0
        old_total_wait = 0
        old_state = -1
        old_action = -1

        while self._step < self._max_steps:

            current_state = self.obtenirEtat()

            current_total_wait = self.collecterTempsAttente()
            reward = old_total_wait - current_total_wait

            if self._step != 0:
                self._Memory.add_sample((old_state, old_action, reward, current_state))

            action = self.choisirAction(current_state, epsilon)

            if self._step != 0 and old_action != action:
                self.definirPhaseJaune(old_action)
                self._simulate(self._yellow_duration)

            self.definirPhaseVerte(action)
            self._simulate(self._green_duration)

            old_state = current_state
            old_action = action
            old_total_wait = current_total_wait

            if reward < 0:
                self._sum_neg_reward += reward

        self._save_episode_stats()
        print("Récompense totale:", self._sum_neg_reward, "- Epsilon:", round(epsilon, 2))
        traci.close()
        simulation_time = round(timeit.default_timer() - start_time, 1)

        print("Entraînement en cours...")
        start_time = timeit.default_timer()
        for _ in tqdm (range(self._training_epochs)):
            self._replay()
        training_time = round(timeit.default_timer() - start_time, 1)

        return simulation_time, training_time


    def _simulate(self, steps_todo):
        if (self._step + steps_todo) >= self._max_steps:  
            steps_todo = self._max_steps - self._step

        while steps_todo > 0:
            traci.simulationStep() 
            self._step += 1 
            steps_todo -= 1
            queue_length = self.obtenirFileAttente()
            self._sum_queue_length += queue_length
            self._sum_waiting_time += queue_length 

    def collecterTempsAttente(self):
        incoming_roads = ["E2TL", "N2TL", "W2TL", "S2TL"]
        car_list = traci.vehicle.getIDList()
        for car_id in car_list:
            wait_time = traci.vehicle.getAccumulatedWaitingTime(car_id)
            road_id = traci.vehicle.getRoadID(car_id)  
            if road_id in incoming_roads:  
                self._waiting_times[car_id] = wait_time
            else:
                if car_id in self._waiting_times: 
                    del self._waiting_times[car_id] 
        total_waiting_time = sum(self._waiting_times.values())
        return total_waiting_time


    def choisirAction(self, state, epsilon):
        if random.random() < epsilon:
            return random.randint(0, self._num_actions - 1) 
        else:
            return np.argmax(self._Model.prediction(state)) 


    def definirPhaseJaune(self, old_action):
        yellow_phase_code = old_action * 2 + 1 
        traci.trafficlight.setPhase("TL", yellow_phase_code)


    def definirPhaseVerte(self, action_number):
        if action_number == 0:
            traci.trafficlight.setPhase("TL", PHASE_NS_GREEN)
        elif action_number == 1:
            traci.trafficlight.setPhase("TL", PHASE_NSL_GREEN)
        elif action_number == 2:
            traci.trafficlight.setPhase("TL", PHASE_EW_GREEN)
        elif action_number == 3:
            traci.trafficlight.setPhase("TL", PHASE_EWL_GREEN)


    def obtenirFileAttente(self):
        halt_N = traci.edge.getLastStepHaltingNumber("N2TL")
        halt_S = traci.edge.getLastStepHaltingNumber("S2TL")
        halt_E = traci.edge.getLastStepHaltingNumber("E2TL")
        halt_W = traci.edge.getLastStepHaltingNumber("W2TL")
        queue_length = halt_N + halt_S + halt_E + halt_W
        return queue_length


    def obtenirEtat(self):
        state = np.zeros(self._num_states)
        car_list = traci.vehicle.getIDList()

        for car_id in car_list:
            lane_pos = traci.vehicle.getLanePosition(car_id)
            lane_id = traci.vehicle.getLaneID(car_id)
            lane_pos = 750 - lane_pos 

            if lane_pos < 7:
                lane_cell = 0
            elif lane_pos < 14:
                lane_cell = 1
            elif lane_pos < 21:
                lane_cell = 2
            elif lane_pos < 28:
                lane_cell = 3
            elif lane_pos < 40:
                lane_cell = 4
            elif lane_pos < 60:
                lane_cell = 5
            elif lane_pos < 100:
                lane_cell = 6
            elif lane_pos < 160:
                lane_cell = 7
            elif lane_pos < 400:
                lane_cell = 8
            elif lane_pos <= 750:
                lane_cell = 9

            if lane_id == "W2TL_0" or lane_id == "W2TL_1" or lane_id == "W2TL_2":
                lane_group = 0
            elif lane_id == "W2TL_3":
                lane_group = 1
            elif lane_id == "N2TL_0" or lane_id == "N2TL_1" or lane_id == "N2TL_2":
                lane_group = 2
            elif lane_id == "N2TL_3":
                lane_group = 3
            elif lane_id == "E2TL_0" or lane_id == "E2TL_1" or lane_id == "E2TL_2":
                lane_group = 4
            elif lane_id == "E2TL_3":
                lane_group = 5
            elif lane_id == "S2TL_0" or lane_id == "S2TL_1" or lane_id == "S2TL_2":
                lane_group = 6
            elif lane_id == "S2TL_3":
                lane_group = 7
            else:
                lane_group = -1

            if lane_group >= 1 and lane_group <= 7:
                car_position = int(str(lane_group) + str(lane_cell)) 
                valid_car = True
            elif lane_group == 0:
                car_position = lane_cell
                valid_car = True
            else:
                valid_car = False 

            if valid_car:
                state[car_position] = 1 

        return state


    def _replay(self):
        batch = self._Memory.get_samples(self._Model.tailleLot)

        if len(batch) > 0:  
            states = np.array([val[0] for val in batch])  
            next_states = np.array([val[3] for val in batch])  

            q_s_a = self._Model.predict_batch(states) 
            q_s_a_d = self._Model.predict_batch(next_states) 

            x = np.zeros((len(batch), self._num_states))
            y = np.zeros((len(batch), self._num_actions))

            for i, b in enumerate(batch):
                state, action, reward, _ = b[0], b[1], b[2], b[3] 
                current_q = q_s_a[i]  
                current_q[action] = reward + self._gamma * np.amax(q_s_a_d[i]) 
                x[i] = state
                y[i] = current_q 

            self._Model.train_batch(x, y)

    def _save_episode_stats(self):
        self._reward_store.append(self._sum_neg_reward)  
        self._cumulative_wait_store.append(self._sum_waiting_time)  
        self._avg_queue_length_store.append(self._sum_queue_length / self._max_steps) 

    @property
    def reward_store(self):
        return self._reward_store


    @property
    def cumulative_wait_store(self):
        return self._cumulative_wait_store


    @property
    def avg_queue_length_store(self):
        return self._avg_queue_length_store

class Memoire:
    def __init__(self, size_max, size_min):
        self._samples = []
        self._size_max = size_max
        self._size_min = size_min

    def add_sample(self, sample):
        self._samples.append(sample)
        if self._size_now() > self._size_max:
            self._samples.pop(0) 

    def get_samples(self, n):
        if self._size_now() < self._size_min:
            return []

        if n > self._size_now():
            return random.sample(self._samples, self._size_now())
        else:
            return random.sample(self._samples, n) 

    def _size_now(self):
        return len(self._samples)

class Visualisation:
    def __init__(self, path, dpi):
            self._path = path
            self._dpi = dpi

    def enregistreDonneeEtGraphique(self, data, nomFichier, xlabel, ylabel):
        min_val = min(data)
        max_val = max(data)

        plt.rcParams.update({'font.size': 30}) 

        plt.plot(data)
        plt.ylabel(ylabel)
        plt.xlabel(xlabel)
        plt.margins(0)
        plt.ylim(min_val - 0.05 * abs(min_val), max_val + 0.05 * abs(max_val))
        fig = plt.gcf()
        fig.set_size_inches(20, 11.25)
        fig.savefig(os.path.join(self._path, 'graphique_'+nomFichier+'.png'), dpi=self._dpi)
        plt.close("all")

        with open(os.path.join(self._path, 'graphique_'+nomFichier + '_data.txt'), "w") as file:
            for value in data:
                    file.write("%s\n" % value)

class EntrainementModele:
    def __init__(self, nbreCouches, width, tailleLot, pasApprentissage, input_dim, output_dim):
        self._input_dim = input_dim
        self._output_dim = output_dim
        self._batch_size = tailleLot
        self._learning_rate = pasApprentissage
        self._model = self.deployerModele(nbreCouches, width)


    def deployerModele(self, nbreCouches, width):
        inputs = keras.Input(shape=(self._input_dim,))
        x = layers.Dense(width, activation='relu')(inputs)
        for _ in range(nbreCouches):
            x = layers.Dense(width, activation='relu')(x)
        outputs = layers.Dense(self._output_dim, activation='linear')(x)

        model = keras.Model(inputs=inputs, outputs=outputs, name='my_model')
        model.compile(loss=losses.mean_squared_error, optimizer=Adam(lr=self._learning_rate))
        return model
    

    def prediction(self, state):
        state = np.reshape(state, [1, self._input_dim])
        return self._model.predict(state)


    def predict_batch(self, states):
        return self._model.predict(states)


    def train_batch(self, states, q_sa):
        self._model.fit(states, q_sa, epochs=1, verbose=0)


    def save_model(self, path):
        self._model.save(os.path.join(path, 'modeleEntrainer.h5'))

    @property
    def input_dim(self):
        return self._input_dim


    @property
    def output_dim(self):
        return self._output_dim


    @property
    def tailleLot(self):
        return self._batch_size


if __name__ == "__main__":

    configuration = importerConfigurationEntrainement(fichierConfiguration='parametres/entrainement.ini')
    sumo_cmd = sumoDef(configuration['gui'], configuration['fichierConfigSumo'], configuration['maxEtapes'])
    path = cheminEntrainementDef(configuration['cheminModeles'])

    Model = EntrainementModele(
        configuration['nbreCouches'], 
        configuration['couchesCachee'], 
        configuration['tailleLot'], 
        configuration['pasApprentissage'], 
        input_dim=configuration['nbreEtats'], 
        output_dim=configuration['nbreActions']
    )

    Memoire = Memoire(
        configuration['tailleMaxMemoire'], 
        configuration['tailleMinMemoire']
    )

    TrafficGen = GenerateurTrafic(
        configuration['maxEtapes'], 
        configuration['nbreVehiculeGenerer']
    )

    Visualisation = Visualisation(
        path, dpi=96
    )
        
    Simulation = Simulation(
        Model,
        Memoire,
        TrafficGen,
        sumo_cmd,
        configuration['gamma'],
        configuration['maxEtapes'],
        configuration['dureeVert'],
        configuration['dureeJaune'],
        configuration['nbreEtats'],
        configuration['nbreActions'],
        configuration['epoqueFormation']
    )
    
    episode = 0
    timestamp_start = datetime.datetime.now()
    
    while episode < configuration['nbreEpisodes']:
        print('\nEpisode', str(episode+1), 'sur', str(configuration['nbreEpisodes']))
        epsilon = 1.0 - (episode / configuration['nbreEpisodes']) 
        simulation_time, training_time = Simulation.run(episode, epsilon)  
        print('Temps de simulation:', simulation_time, 's - Temps d\'entrainnement:', training_time, 's - Total:', round(simulation_time+training_time, 1), 's')
        episode += 1

    print("\n Heure de début:", timestamp_start)
    print("Heure de fin:", datetime.datetime.now())
    print("Informations sur la session enregistrées sur:", path)

    Model.save_model(path)

    copyfile(src='parametres\entrainement.ini', dst=os.path.join(path, 'entrainement.ini'))

    Visualisation.enregistreDonneeEtGraphique(data=Simulation.reward_store, nomFichier='récompense', xlabel='Episode', ylabel='Le cumule de récompense négative')
    
    Visualisation.enregistreDonneeEtGraphique(data=Simulation.cumulative_wait_store, nomFichier='retard', xlabel='Episode', ylabel='Retard cumulé(s)')
    
    Visualisation.enregistreDonneeEtGraphique(data=Simulation.avg_queue_length_store, nomFichier='file d\'attente', xlabel='Episode', ylabel='Longueur moyenne de la file d\'attente (véhicules)')