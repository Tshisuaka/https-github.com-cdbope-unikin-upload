from base64 import decode
import configparser
from quopri import decodestring
from xml.etree.ElementTree import tostring
from cv2 import getVersionString
from sumolib import checkBinary
import os
import sys


def importerConfigurationEntrainement(fichierConfiguration):
    content = configparser.ConfigParser()
    content.read(fichierConfiguration)
    configuration = {}
    configuration['gui'] = content['simulation'].getboolean('gui')
    configuration['nbreEpisodes'] = content['simulation'].getint('nbreEpisodes')
    configuration['maxEtapes'] = content['simulation'].getint('maxEtapes')
    configuration['nbreVehiculeGenerer'] = content['simulation'].getint('nbreVehiculeGenerer')
    configuration['dureeVert'] = content['simulation'].getint('dureeVert')
    configuration['dureeJaune'] = content['simulation'].getint('dureeJaune')
    configuration['nbreCouches'] = content['modele'].getint('nbreCouches')
    configuration['couchesCachee'] = content['modele'].getint('couchesCachee')
    configuration['tailleLot'] = content['modele'].getint('tailleLot')
    configuration['pasApprentissage'] = content['modele'].getfloat('pasApprentissage')
    configuration['epoqueFormation'] = content['modele'].getint('epoqueFormation')
    configuration['tailleMinMemoire'] = content['memoire'].getint('tailleMinMemoire')
    configuration['tailleMaxMemoire'] = content['memoire'].getint('tailleMaxMemoire')
    configuration['nbreEtats'] = content['agent'].getint('nbreEtats')
    configuration['nbreActions'] = content['agent'].getint('nbreActions')
    configuration['gamma'] = content['agent'].getfloat('gamma')
    configuration['cheminModeles'] = content['chemin']['cheminModeles']
    configuration['fichierConfigSumo'] = content['chemin']['fichierConfigSumo']
    
    return configuration

def cheminTestDef(cheminModeles, modele_n):
    modele_n = str(modele_n)

    cheminDossierModele = os.path.join(os.getcwd(), cheminModeles, 'modele_'+ modele_n, '')

    if os.path.isdir(cheminDossierModele):    
        cheminGraphique = os.path.join(cheminDossierModele, 'test', '')
        os.makedirs(os.path.dirname(cheminGraphique), exist_ok=True)
        return cheminDossierModele, cheminGraphique
    else: 
        sys.exit("Le numéro de modèle spécifié n'existe pas dans le dossier des modèles")

def importerConfigurationTest(fichierConfiguration):
    content = configparser.ConfigParser()
    content.read(fichierConfiguration)
    configuration = {}
    configuration['gui'] = content['simulation'].getboolean('gui')
    configuration['maxEtapes'] = content['simulation'].getint('maxEtapes')
    configuration['nbreVehiculeGenerer'] = content['simulation'].getint('nbreVehiculeGenerer')
    configuration['graineEpisode'] = content['simulation'].getint('graineEpisode')
    configuration['dureeVert'] = content['simulation'].getint('dureeVert')
    configuration['dureeJaune'] = content['simulation'].getint('dureeJaune')
    configuration['nbreEtats'] = content['agent'].getint('nbreEtats')
    configuration['nbreActions'] = content['agent'].getint('nbreActions')
    configuration['fichierConfigSumo'] = content['chemin']['fichierConfigSumo']
    configuration['cheminModeles'] = content['chemin']['cheminModeles']
    configuration['modeleATester'] = content['chemin'].getint('modeleATester') 
    return configuration

def cheminEntrainementDef(cheminModeles):
    cheminModeles = os.path.join(os.getcwd(), cheminModeles, '')
    os.makedirs(os.path.dirname(cheminModeles), exist_ok=True)

    cheminContenu = os.listdir(cheminModeles)
    if cheminContenu:
        ancienneVersion = [int(name.split("_")[1]) for name in cheminContenu]
        nouvelleVersion = str(max(ancienneVersion) + 1)
    else:
        nouvelleVersion = '1'

    cheminDonnees = os.path.join(cheminModeles, 'modele_'+nouvelleVersion, '')
    os.makedirs(os.path.dirname(cheminDonnees), exist_ok=True)
    return cheminDonnees

def sumoDef(gui, fichierConfigSumo, maxEtapes):
    if 'SUMO_HOME' in os.environ:
        tools = os.path.join(os.environ['SUMO_HOME'], 'tools')
        sys.path.append(tools)
    else:
        sys.exit("veuillez déclarer la variable d'environnement 'SUMO_HOME'")
  
    if gui == False:
        sumoBinary = checkBinary('sumo')
    else:
        sumoBinary = checkBinary('sumo-gui')
 
    sumo_cmd = [sumoBinary, "-c", os.path.join('parametres/carrefour', fichierConfigSumo), "--no-step-log", "true", "--waiting-time-memory", str(maxEtapes)]

    return sumo_cmd
